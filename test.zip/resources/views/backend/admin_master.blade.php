
@include('backend.includes.header')
@yield('admin_content')
@include('backend.includes.footer')