<?php $__env->startSection('page_title','Category List'); ?>
<?php $__env->startSection('admin_content'); ?>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Category List Table</strong>
                <small>
                    <p class="text-center alert-success"><?php echo e(Session::get('message_success')); ?></p>
                    <p class="text-center  alert-danger"><?php echo e(Session::get('message_error')); ?></p>
                </small>
            </div>
            <div class="card-body">
                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th width="10%">SL</th>
                        <th width="20%">Title</th>
                        <th width="10%">Major Category</th>
                        <th width="20%">Name</th>
                        <th width="20%">Image</th>
                        <th width="20%">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i=0;?>
                    <?php $__currentLoopData = $category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++;?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($category->cat_title); ?></td>
                            <td>
                                <?php if($category->cat_major=='1'): ?>
                                    Yes
                                <?php else: ?>
                                    No
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($category->cat_name); ?></td>
                            <td><img width="60" height="80" src="<?php echo e(asset($category->cat_image)); ?>" alt="<?php echo e($category->cat_title); ?>"></td>
                            <td>
                                <a class="btn btn-primary" href="<?php echo e(url('/edit-category/'.$category->id)); ?>"><i class="fa fa-edit"></i>Edit</a>
                                <a class="btn btn-danger" href="<?php echo e(url('/delete-category/'.$category->id)); ?>"><i class="fa fa-trash-o"></i>Delete </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>