<?php $__env->startSection('main_content'); ?>
 <header class="page-header">
        <h1 class="page-title">Welding &amp; Fabrication</h1>
        <ol class="breadcrumb page-breadcrumb">
            <li><a href="../index.html">Home</a>
            </li>
            <li><a href="#">Welding &amp; Fabrication</a>
            </li>
        </ol>
        <ul class="category-selections clearfix">
            <li>
                <a class="fa fa-th-large category-selections-icon active" href="#"></a>
            </li>
            <li>
                <a class="fa fa-th-list category-selections-icon" href="#"></a>
            </li>
            <li><span class="category-selections-sign">Sort by :</span>
              <?php echo Form::open(['url'=>'product-sorting','method'=>'GET']); ?>

                <select onchange="this.form.submit()" class="category-selections-select" name="product_sort">
                    <option selected disabled>--Default--</option>
                    <option value="new_est">Newest First</option>
                    <option value="best_rated">Best Raited</option>
                    <option value="low_price">Price : Lowest First</option>
                    <option value="high_price">Price : Highest First</option>
                    <option value="a_to_z">Title : A - Z</option>
                    <option value="z_to_a">Title : Z - A</option>
                </select>
                <?php echo Form::close(); ?>

            </li>
            <li><span class="category-selections-sign">Items :</span>
                <?php echo Form::open(['url'=>'product-sorting-item','method'=>'GET']); ?>

                <select onchange="this.form.submit()" class="category-selections-select" name="product_item">
                    <option selected disabled>--Select Item--</option>
                    <option value="nine_item">9 / page</option>
                    <option  value="twelve_item">12 / page</option>
                    <option value="eighteen_item">18 / page</option>
                    <option value="all_item">All</option>
                </select>
                <?php echo Form::close(); ?>

            </li>
        </ul>
    </header>

    <div class="row">
        <div class="col-md-3">
            <aside class="category-filters">
                <div class="category-filters-section">
                    <h3 class="widget-title-sm">Category</h3>
                    <input type="hidden" id="category" value="2">
                    <input type="hidden" id="category_level" value="category">
                    <?php echo Form::open(['url'=>'product-by-category','method'=>'GET']); ?>

                    <select onchange="this.form.submit()" class="category-selections-select" name="pro_by_cat">
                        <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" class="main-category" selected=""><?php echo e($category->cat_name); ?></option>
                            <?php $__currentLoopData = $all_sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($sub_category->cat_id==$category->id): ?>
                            <option value="<?php echo e($sub_category->id); ?>" class="sub-category" >&nbsp;&nbsp;<?php echo e($sub_category->sub_cat_name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo Form::close(); ?>

                </div>

                <div class="category-filters-section">
                    <h3 class="widget-title-sm">Location</h3>
                    <input type="hidden" id="category" value="2">
                    <input type="hidden" id="category_level" value="category">

                    <select class="category-selections-select">
                        <option>Abia</option>
                        <option>Adamawa</option>
                        <option>Akwa Ibom	</option>
                        <option>Anambra</option>
                        <option>Bauchi</option>
                        <option>Bayelsa</option>
                        <option>Benue</option>
                        <option>Borno</option>
                        <option>Cross River	</option>
                        <option>Delta	</option>
                        <option>Ebonyi	</option>
                        <option>Edo	</option>
                        <option>Ekiti	</option>
                        <option>Enugu	</option>
                        <option>Gombe	</option>
                        <option>Imo	</option>
                        <option>Jigawa	</option>
                        <option>Kaduna	</option>
                        <option>Kano	</option>
                        <option>Katsina	</option>
                        <option>Kebbi	</option>
                        <option>Kogi	</option>
                        <option>Kwara	</option>




                    </select>

                </div>
                <div class="category-filters-section">
                    <h3 class="widget-title-sm">Price</h3>

                    <!--<span class="rangeValues"></span>
                    <input value="500" min="500" max="50000" step="500" type="range">
                    <input value="50000" min="500" max="50000" step="500" type="range">-->

                    <input type="text" id="price-slider" />

                </div>

                <form>
                    <div class="category-filters-section">
                        <h3 class="widget-title-sm">Payment type</h3>
                        <div class='checkbox'>
                            <label>
                                <input class='i-check form' name='manufacturer[]' type='checkbox' value=1 />Pay on delivery

                            </label>
                        </div>

                        <div class='checkbox'>
                            <label>
                                <input class='i-check form' name='manufacturer[]' type='checkbox' value=1 />Pay after inspection
                            </label>
                        </div>

                        <div class='checkbox'>
                            <label>
                                <input class='i-check form' name='manufacturer[]' type='checkbox' value=1 />Pay in Advance

                            </label>
                        </div>

                    </div>
                    <div class="category-filters-section">
                        <h3 class="widget-title-sm">Pricing</h3>
                        <div class='checkbox'>
                            <label>
                                <input class='i-check form' name='model[]' type='checkbox' value=1 />Instant payment
                            </label>
                        </div>
                        <div class='checkbox'>
                            <label>
                                <input class='i-check form' name='model[]' type='checkbox' value=1 />15 days Payment
                            </label>
                        </div>
                        <div class='checkbox'>
                            <label>
                                <input class='i-check form' name='model[]' type='checkbox' value=1 />30 days Payment
                            </label>
                        </div>
                    </div>


                </form>
            </aside>
        </div>
        <div class="col-md-9">
            <div class="row" id="data" data-gutter="15">
                <?php $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class='col-md-4'>
                    <div class="product ">
                        <div class="product-img-wrap">
                            <img class="product-img-primary" width="253" height="253" src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>" title="<?php echo e($product->name); ?>" />
                            <img class="product-img-alt" width="253" height="253" src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>" title="<?php echo e($product->name); ?>" />
                        </div>
                        <a class="product-link" href="<?php echo e(url('/product-details/'.$product->id)); ?>"></a>
                        <div class="product-caption">
                            <ul class="product-caption-rating">
                                <li class="rated"><i class="fa fa-star"></i>
                                </li>
                                <li class="rated"><i class="fa fa-star"></i>
                                </li>
                                <li class="rated"><i class="fa fa-star"></i>
                                </li>
                                <li class="rated"><i class="fa fa-star"></i>
                                </li>
                                <li class="rated"><i class="fa fa-star"></i>
                                </li>
                            </ul>
                            <h5 class="product-caption-title"><?php echo e($product->name); ?></h5>
                            <div class="product-caption-price">


                       <span class="product-caption-price-new">
                          <?php if($product->discount_price==NULL): ?>
                               $ <?php echo e($product->price); ?>

                           <?php endif; ?>
                        </span>
                                <?php if($product->discount_price!=NULL): ?>
                                    <span class="product-caption-price-old">$<?php echo e($product->price); ?></span>
                                    <span class="product-caption-price-new">$<?php echo e($product->discount_price); ?></span>
                                <?php endif; ?>
                            </div>
                            <ul class="product-caption-feature-list">
                                <li><?php echo e($product->qty); ?> left</li>
                                <li>Free Shipping</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
    <div class="gap"></div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.front_view.front_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>