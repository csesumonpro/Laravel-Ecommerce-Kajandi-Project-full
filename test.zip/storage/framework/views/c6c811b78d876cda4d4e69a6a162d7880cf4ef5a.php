<div class="col-md-3">
    <div class="clearfix">
        <ul class="dropdown-menu dropdown-menu-category dropdown-menu-category-hold dropdown-menu-category-sm">
        <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(url('/product-category/'.$category->id)); ?>"><i class="fa fa-fire-extinguisher dropdown-menu-category-icon"></i><?php echo e($category->cat_name); ?></a>
                <div class="dropdown-menu-category-section">
                    <div class="dropdown-menu-category-section-inner">
                        <div class="dropdown-menu-category-section-content">
                            <div class="row">
                                <h5 class="dropdown-menu-category-title"><?php echo e($category->cat_title); ?></h5>
                                <?php $__currentLoopData = $all_sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    

                                    <ul class="dropdown-menu-category-list">
                                       <?php if($sub_category->cat_id==$category->id): ?>
                                        <li><a href="<?php echo e(url('/product-sub-category/'.$sub_category->id)); ?>"><?php echo e($sub_category->sub_cat_name); ?></a>
                                            <p><?php echo e($sub_category->sub_cat_desc); ?></p>
                                        </li>
                                       <?php endif; ?>
                                    </ul>
                                </div>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <img class="dropdown-menu-category-section-theme-img" src="<?php echo e(asset($category->cat_image)); ?>" alt="Image Alternative text" title="<?php echo e($category->cat_title); ?>" style="right: -10px;" />
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <br><br>
        </ul>
    </div>
</div>
