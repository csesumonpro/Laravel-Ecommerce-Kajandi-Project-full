<?php $__env->startSection('page-title','My Wishlist'); ?>
<?php $__env->startSection('main_content'); ?>
    <header class="page-header">
        <h1 class="page-title">My Wishlist</h1>
    </header>
    <div class="row">
        <div class="col-md-9">
            <div class="table-responsive">
                <form action="#updatePost/" method="post">
                    <div class="form-wrapper">
                        <table border="0">
                            <tr>
                                <th>Product</th>
                                <th>Title</th>
                                <th>Price</th>
                                <th>Availability</th>
                                <th>Add to cart</th>
                                <th>Remove</th>
                            </tr>
                            <?php
                            $wishlist = DB::table('products')
                                ->join('wishlists', 'products.id', '=', 'wishlists.product_id')
                                ->where('wishlists.user_id',Auth::user()->id)
                                ->select('products.*', 'wishlists.*')
                                ->get();
                            ?>
                            <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="single-item">
                                <td><img src="<?php echo e(asset($wl->image)); ?>"></td>
                                <td><span class="pro-name"><?php echo e($wl->name); ?></span></td>
                                <td><span class="price">$<?php echo e($wl->price); ?></span></td>
                                <td><span class="availability text-success">
                                        <?php if($wl->availability=='1'): ?>
                                            In Stock
                                            <?php elseif($wl->availability=='2'): ?>
                                           Out Of Stock
                                            <?php endif; ?>
                                    </span></td>
                               <?php echo e(Form::open(['url'=>'add-to-cart','method'=>'POST'])); ?>

                                <td>
                                    <input type="hidden" name="qty" value="1">
                                    <input type="hidden" name="product_id" value="<?php echo e($wl->product_id); ?>">
                                    <button type="submit" class="button add-cart-item"  href="" >Add to cart</button>
                                </td>
                                <?php echo Form::close(); ?>

                                <td><a class="button remove-item" href="<?php echo e(url('remove-wishlist-item/'.$wl->id)); ?>" title="Remove item"><span><span><i class="fa fa-times-circle"></i></span></span></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-md-3">
            <div class="accounts-menu">
                <h2>My Account</h2>
                <ul>
                    <li><a href="#">Account control panel</a></li>
                    <li><a href="#">Personal information</a></li>
                    <li><a href="#">Address book</a></li>
                    <li><a href="#">My orders</a></li>
                    <li><a href="#">My Reviews &amp; Ratings</a></li>
                    <li><a href="#">My Saved Items</a></li>
                    <li><a href="#">My coupons</a></li>
                    <li><a href="#">Newsletter preferences</a></li>
                </ul>
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="shopping654">
                <a href="<?php echo e(route('shop')); ?>">Continue shopping</a> <a href="<?php echo e(route('compare')); ?>">Compare</a>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.front_view.front_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>