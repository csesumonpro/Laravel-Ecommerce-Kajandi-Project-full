<?php $__env->startSection('page_title','Product List'); ?>
<?php $__env->startSection('admin_content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Category List Table</strong>
            <small>
                <p class="text-center  alert-success"><?php echo e(Session::get('message_success')); ?></p>
                <p class="text-center  alert-danger"><?php echo e(Session::get('message_error')); ?></p>
            </small>
        </div>
        <div class="card-body">
            <table id="bootstrap-data-table" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th width="5%">SL</th>
                    <th width="45%">Title</th>
                    <th width="10%">Price</th>
                    <th width="10%">Quantity</th>
                    <th width="10%">Image</th>
                    <th width="20%">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $i=0;?>
                <?php $__currentLoopData = $product_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $i++;?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td><?php echo e($product->qty); ?></td>
                    <td><img src="<?php echo e($product->image); ?>" alt="" width="50" height="40"></td>
                    <td>
                        <a class="btn btn-primary" href="<?php echo e(url('/edit-product/'.$product->id)); ?>"><i class="fa fa-edit"></i></a>
                        <a class="btn btn-danger" href="<?php echo e(url('/delete-product/'.$product->id)); ?>"><i class="fa fa-trash-o"></i></a>
                        <a class="btn btn-info" href="<?php echo e(url('/product-view/'.$product->id)); ?>"><i class="fa fa-info"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>