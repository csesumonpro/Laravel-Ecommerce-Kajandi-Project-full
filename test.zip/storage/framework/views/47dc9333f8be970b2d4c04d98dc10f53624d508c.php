<?php $__env->startSection('page_title','Category Edit'); ?>
<?php $__env->startSection('admin_content'); ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header"><strong>Category Update Form</strong>
                <small>
                    <p class="text-center  alert-success"><?php echo e(Session::get('message_success')); ?></p>
                    <p class="text-center  alert-danger"><?php echo e(Session::get('message_error')); ?></p>
                </small>
            </div>
            <?php echo Form::open(['method'=>'POST','url'=>'update-category','enctype'=>'multipart/form-data']); ?>

            <div class="card-body card-block">
                <div class="form-group">
                    <label for="company" class=" form-control-label">Update Category Title</label>
                    <input type="text" id="company" name="cat_title" value="<?php echo e($category_by_id->cat_title); ?>" class="form-control">
                    <input type="hidden" value="<?php echo e($category_by_id->id); ?>" name="id"/>
                    <?php if($errors->has('cat_title')): ?>
                        <div class="error"><?php echo e($errors->first('cat_title')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="company" class=" form-control-label">Update Category Name</label>
                    <input type="text" id="company" name="cat_name" value="<?php echo e($category_by_id->cat_name); ?>" class="form-control">
                    <?php if($errors->has('cat_name')): ?>
                        <div class="error"><?php echo e($errors->first('cat_name')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="company" class=" form-control-label">Update Category Image</label>
                    <input type="file" id="company" name="cat_image" class="form-control">
                    <img width="100" height="100" src="<?php echo e(asset($category_by_id->cat_image)); ?>" alt="<?php echo e($category_by_id->cat_title); ?>">
                    <?php if($errors->has('cat_image')): ?>
                        <div class="error"><?php echo e($errors->first('cat_image')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-group form-check-inline form-check">
                    <label for="inline-checkbox1" class="form-check-label ">
                        <input type="checkbox" id="inline-checkbox1" name="cat_major"
                               <?php if($category_by_id->cat_major=='1'): ?>
                               checked
                               <?php endif; ?>
                               value="1" class="form-check-input">Set as Major
                    </label>
                    <?php if($errors->has('cat_major')): ?>
                        <div class="error"><?php echo e($errors->first('cat_major')); ?></div>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-dark btn-lg btn-block">Update</button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>