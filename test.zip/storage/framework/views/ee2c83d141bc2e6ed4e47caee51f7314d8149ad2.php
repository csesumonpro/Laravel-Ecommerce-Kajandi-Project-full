<?php echo $__env->make('frontend.front_view.includes.header_copy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="container">
    <div class="gap gap-small"></div>
    <div class="row row-sm-gap" data-gutter="10">

        <?php echo $__env->yieldContent('main_sidebar'); ?>
        <?php echo $__env->yieldContent('main_slider'); ?>


    </div>

    <div class="gap"></div>

    <?php echo $__env->yieldContent('main_content'); ?>

</div>


<?php echo $__env->make('frontend.front_view.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
