<?php $__env->startSection('page-title','Checkout'); ?>
<?php $__env->startSection('main_content'); ?>
<header class="page-header">
    <h3 class="page-title">Payment for #9897463c Order</h3>
</header>
<div class="row">
    <div class="col-md-6">
        <div class="pay-order">
            <form method="post" action="#updatePost/">

                <table class="">
                    <thead>
                    <tr>
                        <th>Product</th>
                        <th>QTY</th>
                        <th>Price</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = Cart::Content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->qty); ?></td>
                        <td>$<?php echo e($item->price*$item->qty); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>Sub Total</td>
                        <td> </td>
                        <td>$<?php echo e(Cart::total()); ?></td>
                    </tr>
                    <tr>
                        <td>Shipping</td>
                        <td> </td>
                        <td>Free </td>
                    </tr>
                    <tr>
                        <td>Total</td>
                        <td> </td>
                        <td>$<?php echo e(Cart::total()); ?></td>
                    </tr>
                    </tbody>
                </table>
            </form>
        </div>


    </div>

    <div class="col-md-6 pay-order986">
        <div class="row">


            <div class="col-md-12">

                <button class="btn btn-primary" href="#">Pay with card</button>
                <button class="btn btn-primary" href="#">Pay on delevary</button>
                <button class="btn btn-primary" href="#">Pay direct to bank </button>
                <button class="btn btn-primary" href="#">Paypal Payment</button>
                <button class="btn btn-primary" href="#">Pay with wallet</button>
            </div>

        </div>
    </div>

</div>
<div class="gap"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.front_view.front_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>